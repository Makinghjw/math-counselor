import LatexRenderer from "./LatexRenderer";
import { Bookmark, BookmarkX, Trash2 } from "lucide-react";

interface BookmarkedFormula {
  topicId: string;
  topicTitle: string;
  label: string;
  latex: string;
}

interface FormulaBookProps {
  bookmarks: BookmarkedFormula[];
  onRemove: (formula: BookmarkedFormula) => void;
}

const FormulaBook = ({ bookmarks, onRemove }: FormulaBookProps) => {
  if (bookmarks.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card p-12 text-center">
        <Bookmark className="mb-3 h-10 w-10 text-muted-foreground/30" />
        <p className="text-lg font-semibold text-muted-foreground">공식 보관함이 비어 있습니다</p>
        <p className="mt-1 text-sm text-muted-foreground/70">
          학습 중 공식 옆의 북마크 아이콘을 눌러 저장하세요
        </p>
      </div>
    );
  }

  // Group by topic
  const grouped = bookmarks.reduce<Record<string, BookmarkedFormula[]>>((acc, b) => {
    if (!acc[b.topicTitle]) acc[b.topicTitle] = [];
    acc[b.topicTitle].push(b);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-foreground">📌 공식 보관함</h2>
        <p className="mt-1 text-sm text-muted-foreground">중요 표시한 공식 {bookmarks.length}개</p>
      </div>

      {Object.entries(grouped).map(([title, formulas]) => (
        <div key={title} className="rounded-xl border border-border bg-card p-5">
          <h3 className="mb-3 text-sm font-semibold text-card-foreground">{title}</h3>
          <div className="space-y-2.5">
            {formulas.map((f, i) => (
              <div
                key={i}
                className="flex items-start justify-between gap-3 rounded-lg bg-secondary/50 px-4 py-3"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground mb-1.5">{f.label}</p>
                  <div className="overflow-x-auto">
                    <LatexRenderer latex={f.latex} displayMode />
                  </div>
                </div>
                <button
                  onClick={() => onRemove(f)}
                  className="shrink-0 p-1 text-muted-foreground/40 hover:text-destructive transition-colors"
                  title="보관함에서 제거"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default FormulaBook;
