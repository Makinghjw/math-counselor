import { useState, useCallback, useRef, useEffect } from "react";

const STORAGE_KEY = "math-helper-study-log";

interface StudyLog {
  date: string;
  seconds: number;
}

export function useStudyTimer() {
  const [isRunning, setIsRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [logs, setLogs] = useState<StudyLog[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(logs));
  }, [logs]);

  const start = useCallback(() => {
    if (isRunning) return;
    setIsRunning(true);
    intervalRef.current = setInterval(() => {
      setElapsed((prev) => prev + 1);
    }, 1000);
  }, [isRunning]);

  const pause = useCallback(() => {
    setIsRunning(false);
    if (intervalRef.current) clearInterval(intervalRef.current);
  }, []);

  const stop = useCallback(() => {
    setIsRunning(false);
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (elapsed > 0) {
      const today = new Date().toISOString().split("T")[0];
      setLogs((prev) => {
        const existing = prev.find((l) => l.date === today);
        if (existing) {
          return prev.map((l) =>
            l.date === today ? { ...l, seconds: l.seconds + elapsed } : l
          );
        }
        return [...prev, { date: today, seconds: elapsed }];
      });
    }
    setElapsed(0);
  }, [elapsed]);

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const formatTime = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  const todayTotal = logs.find(
    (l) => l.date === new Date().toISOString().split("T")[0]
  )?.seconds ?? 0;

  return { isRunning, elapsed, start, pause, stop, formatTime, logs, todayTotal };
}
