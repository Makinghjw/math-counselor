import { MathTopic, getTopicById, GRADES } from "@/data/mathCurriculum";
import LatexRenderer from "./LatexRenderer";
import { ArrowLeft, Bookmark, BookmarkCheck, ChevronLeft } from "lucide-react";

interface TopicDetailProps {
  topic: MathTopic;
  onBack: () => void;
  onNavigate: (topicId: string) => void;
  isBookmarked: (topicId: string, label: string) => boolean;
  onToggleBookmark: (formula: { topicId: string; topicTitle: string; label: string; latex: string }) => void;
}

const TopicDetail = ({ topic, onBack, onNavigate, isBookmarked, onToggleBookmark }: TopicDetailProps) => {
  const prerequisite = topic.prerequisiteId ? getTopicById(topic.prerequisiteId) : null;
  const grade = GRADES.find((g) => g.id === topic.grade);

  return (
    <div className="mx-auto max-w-2xl">
      <button
        onClick={onBack}
        className="mb-4 flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        목록으로 돌아가기
      </button>

      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <span className="inline-block rounded-md bg-secondary px-2.5 py-1 text-xs font-medium text-secondary-foreground">
          {grade?.label}
        </span>
        <h1 className="mt-3 text-2xl font-bold text-card-foreground">{topic.title}</h1>

        {/* 핵심 정의 */}
        <section className="mt-6">
          <h2 className="flex items-center gap-2 text-lg font-semibold text-primary">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            핵심 정의
          </h2>
          <ul className="mt-3 space-y-2">
            {topic.definitions.map((def, i) => (
              <li key={i} className="rounded-lg bg-secondary/50 px-4 py-3 text-sm leading-relaxed text-card-foreground">
                {def}
              </li>
            ))}
          </ul>
        </section>

        {/* 필수 공식 */}
        <section className="mt-6">
          <h2 className="flex items-center gap-2 text-lg font-semibold text-accent">
            <span className="h-1.5 w-1.5 rounded-full bg-accent" />
            필수 공식
          </h2>
          <div className="mt-3 space-y-3">
            {topic.formulas.map((formula, i) => {
              const bookmarked = isBookmarked(topic.id, formula.label);
              return (
                <div
                  key={i}
                  className="flex items-start justify-between gap-3 rounded-lg border border-border bg-card p-4"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-muted-foreground mb-2">{formula.label}</p>
                    <div className="overflow-x-auto">
                      <LatexRenderer latex={formula.latex} displayMode />
                    </div>
                  </div>
                  <button
                    onClick={() =>
                      onToggleBookmark({
                        topicId: topic.id,
                        topicTitle: topic.title,
                        label: formula.label,
                        latex: formula.latex,
                      })
                    }
                    className={`shrink-0 p-1.5 rounded-md transition-colors ${
                      bookmarked
                        ? "text-primary bg-primary/10"
                        : "text-muted-foreground/40 hover:text-primary hover:bg-primary/5"
                    }`}
                    title={bookmarked ? "북마크 해제" : "공식 보관함에 추가"}
                  >
                    {bookmarked ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
                  </button>
                </div>
              );
            })}
          </div>
        </section>

        {/* 내신 꿀팁 */}
        <section className="mt-6">
          <h2 className="flex items-center gap-2 text-lg font-semibold text-warning">
            <span className="h-1.5 w-1.5 rounded-full bg-warning" />
            내신 꿀팁
          </h2>
          <ul className="mt-3 space-y-2">
            {topic.tips.map((tip, i) => (
              <li
                key={i}
                className="flex gap-2.5 rounded-lg bg-warning/5 border border-warning/20 px-4 py-3 text-sm text-card-foreground"
              >
                <span className="shrink-0 text-warning font-bold">💡</span>
                {tip}
              </li>
            ))}
          </ul>
        </section>

        {/* 이전 단계 복습 */}
        {prerequisite && (
          <div className="mt-8 border-t border-border pt-6">
            <button
              onClick={() => onNavigate(prerequisite.id)}
              className="flex w-full items-center gap-3 rounded-xl border border-primary/20 bg-primary/5 p-4 text-left transition-all hover:bg-primary/10"
            >
              <ChevronLeft className="h-5 w-5 text-primary" />
              <div>
                <p className="text-xs font-medium text-primary">이전 단계 복습하기</p>
                <p className="text-sm font-semibold text-card-foreground">{prerequisite.title}</p>
                <p className="text-xs text-muted-foreground">
                  {GRADES.find((g) => g.id === prerequisite.grade)?.label}
                </p>
              </div>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default TopicDetail;
