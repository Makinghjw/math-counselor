import { useState, useCallback, useEffect } from "react";

interface BookmarkedFormula {
  topicId: string;
  topicTitle: string;
  label: string;
  latex: string;
}

const STORAGE_KEY = "math-helper-bookmarks";

export function useBookmarks() {
  const [bookmarks, setBookmarks] = useState<BookmarkedFormula[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookmarks));
  }, [bookmarks]);

  const toggleBookmark = useCallback((formula: BookmarkedFormula) => {
    setBookmarks((prev) => {
      const exists = prev.some(
        (b) => b.topicId === formula.topicId && b.label === formula.label
      );
      if (exists) {
        return prev.filter(
          (b) => !(b.topicId === formula.topicId && b.label === formula.label)
        );
      }
      return [...prev, formula];
    });
  }, []);

  const isBookmarked = useCallback(
    (topicId: string, label: string) =>
      bookmarks.some((b) => b.topicId === topicId && b.label === label),
    [bookmarks]
  );

  return { bookmarks, toggleBookmark, isBookmarked };
}
