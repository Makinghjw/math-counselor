export interface MathTopic {
  id: string;
  grade: string;
  category: string; // 함수, 기하, 수와연산, 확률과통계, 문자와식
  title: string;
  definitions: string[];
  formulas: { label: string; latex: string }[];
  tips: string[];
  prerequisiteId?: string; // links to previous topic
}

export const GRADES = [
  { id: "mid1", label: "중1" },
  { id: "mid2", label: "중2" },
  { id: "mid3", label: "중3" },
  { id: "common", label: "고등 공통" },
  { id: "math12", label: "수I/II" },
  { id: "calculus", label: "미적분" },
] as const;

export const CATEGORIES = [
  { id: "numbers", label: "수와 연산", color: "primary" },
  { id: "algebra", label: "문자와 식", color: "accent" },
  { id: "functions", label: "함수", color: "success" },
  { id: "geometry", label: "기하", color: "warning" },
  { id: "statistics", label: "확률과 통계", color: "destructive" },
] as const;

export const TOPICS: MathTopic[] = [
  // 중1
  {
    id: "mid1-numbers-1",
    grade: "mid1",
    category: "numbers",
    title: "정수와 유리수",
    definitions: [
      "양의 정수(자연수), 0, 음의 정수를 통틀어 정수라 한다.",
      "정수와 정수가 아닌 유리수를 통틀어 유리수라 한다.",
      "유리수는 분수 a/b (b≠0) 꼴로 나타낼 수 있는 수이다.",
    ],
    formulas: [
      { label: "절댓값", latex: "|a| = \\begin{cases} a & (a > 0) \\\\ 0 & (a = 0) \\\\ -a & (a < 0) \\end{cases}" },
      { label: "덧셈의 교환법칙", latex: "a + b = b + a" },
      { label: "곱셈의 분배법칙", latex: "a(b+c) = ab + ac" },
    ],
    tips: [
      "수직선에서 양수는 오른쪽, 음수는 왼쪽!",
      "절댓값은 원점으로부터의 거리이므로 항상 0 이상",
      "음수 × 음수 = 양수 (부호 규칙 꼭 외우기)",
    ],
  },
  {
    id: "mid1-algebra-1",
    grade: "mid1",
    category: "algebra",
    title: "문자와 식",
    definitions: [
      "문자를 사용하여 수량 사이의 관계를 나타낸 것을 식이라 한다.",
      "항: 수 또는 문자의 곱으로 이루어진 식",
      "계수: 문자에 곱해진 수",
    ],
    formulas: [
      { label: "일차식의 덧셈", latex: "(ax + b) + (cx + d) = (a+c)x + (b+d)" },
      { label: "일차방정식", latex: "ax + b = 0 \\Rightarrow x = -\\frac{b}{a}" },
    ],
    tips: [
      "등호(=)가 있으면 등식, 없으면 부등식!",
      "이항할 때 부호 바꾸는 것 잊지 말기",
      "내신에서 '항등식'과 '방정식'의 차이 자주 출제",
    ],
  },
  {
    id: "mid1-functions-1",
    grade: "mid1",
    category: "functions",
    title: "좌표평면과 그래프",
    definitions: [
      "순서쌍 (a, b)에서 a를 x좌표, b를 y좌표라 한다.",
      "정비례: y = ax (a ≠ 0)",
      "반비례: y = a/x (a ≠ 0)",
    ],
    formulas: [
      { label: "정비례 관계", latex: "y = ax \\quad (a \\neq 0)" },
      { label: "반비례 관계", latex: "y = \\frac{a}{x} \\quad (a \\neq 0)" },
    ],
    tips: [
      "정비례 그래프는 원점을 반드시 지남",
      "반비례 그래프는 x축, y축에 한없이 가까워지지만 만나지 않음",
    ],
  },
  {
    id: "mid1-geometry-1",
    grade: "mid1",
    category: "geometry",
    title: "기본 도형과 작도",
    definitions: [
      "점, 선, 면은 도형의 기본 요소이다.",
      "직선은 양쪽으로 끝없이 뻗은 곧은 선이다.",
      "교점: 두 직선이 만나는 점",
    ],
    formulas: [
      { label: "맞꼭지각", latex: "\\angle a = \\angle c, \\quad \\angle b = \\angle d" },
      { label: "동위각·엇각", latex: "l \\parallel m \\Rightarrow \\text{동위각, 엇각이 같다}" },
    ],
    tips: [
      "평행선에서 동위각과 엇각의 성질은 증명 문제의 핵심",
      "작도는 눈금 없는 자와 컴퍼스만 사용",
    ],
  },
  {
    id: "mid1-statistics-1",
    grade: "mid1",
    category: "statistics",
    title: "자료의 정리와 해석",
    definitions: [
      "도수: 각 계급에 속하는 자료의 수",
      "상대도수: 도수/전체 도수",
      "히스토그램: 도수분포표를 막대그래프로 나타낸 것",
    ],
    formulas: [
      { label: "상대도수", latex: "\\text{상대도수} = \\frac{\\text{그 계급의 도수}}{\\text{전체 도수}}" },
    ],
    tips: [
      "상대도수의 합은 항상 1",
      "계급의 크기(폭)가 같아야 비교 가능",
    ],
  },

  // 중2
  {
    id: "mid2-numbers-1",
    grade: "mid2",
    category: "numbers",
    title: "유리수와 순환소수",
    definitions: [
      "유한소수: 소수점 아래 끝이 있는 소수",
      "순환소수: 소수점 아래에서 일정한 숫자가 반복되는 소수",
      "순환마디: 반복되는 부분",
    ],
    formulas: [
      { label: "순환소수 → 분수 변환", latex: "0.\\dot{a} = \\frac{a}{9}, \\quad 0.\\dot{a}\\dot{b} = \\frac{ab}{99}" },
    ],
    tips: [
      "기약분수의 분모의 소인수가 2와 5뿐이면 유한소수",
      "순환소수도 유리수이다!",
    ],
    prerequisiteId: "mid1-numbers-1",
  },
  {
    id: "mid2-algebra-1",
    grade: "mid2",
    category: "algebra",
    title: "식의 계산과 부등식",
    definitions: [
      "단항식: 하나의 항으로 이루어진 식",
      "다항식: 두 개 이상의 항의 합으로 이루어진 식",
      "연립방정식: 두 개 이상의 방정식을 한 쌍으로 묶은 것",
    ],
    formulas: [
      { label: "지수법칙", latex: "a^m \\times a^n = a^{m+n}, \\quad (a^m)^n = a^{mn}" },
      { label: "연립방정식", latex: "\\begin{cases} ax + by = e \\\\ cx + dy = f \\end{cases}" },
    ],
    tips: [
      "연립방정식은 가감법, 대입법 모두 연습하기",
      "부등식에서 음수를 곱하면 부등호 방향이 바뀜!",
    ],
    prerequisiteId: "mid1-algebra-1",
  },
  {
    id: "mid2-functions-1",
    grade: "mid2",
    category: "functions",
    title: "일차함수",
    definitions: [
      "함수: x값이 정해지면 y값이 하나로 정해지는 관계",
      "일차함수: y = ax + b (a ≠ 0) 꼴로 나타내어지는 함수",
      "기울기: x의 값이 1만큼 증가할 때 y의 증가량",
    ],
    formulas: [
      { label: "일차함수", latex: "y = ax + b \\quad (a \\neq 0)" },
      { label: "기울기", latex: "a = \\frac{y_2 - y_1}{x_2 - x_1}" },
      { label: "x절편, y절편", latex: "x\\text{절편}: -\\frac{b}{a}, \\quad y\\text{절편}: b" },
    ],
    tips: [
      "기울기의 부호로 그래프의 방향을 알 수 있음",
      "두 직선이 평행 ⟺ 기울기가 같다",
      "일차함수와 일차방정식의 관계는 내신 단골 문제",
    ],
    prerequisiteId: "mid1-functions-1",
  },
  {
    id: "mid2-geometry-1",
    grade: "mid2",
    category: "geometry",
    title: "삼각형과 사각형의 성질",
    definitions: [
      "이등변삼각형: 두 변의 길이가 같은 삼각형",
      "합동: 모양과 크기가 같은 두 도형",
      "삼각형의 합동 조건: SSS, SAS, ASA",
    ],
    formulas: [
      { label: "삼각형 내각의 합", latex: "\\angle A + \\angle B + \\angle C = 180°" },
      { label: "외각 정리", latex: "\\angle ACD = \\angle A + \\angle B" },
    ],
    tips: [
      "합동 조건 3가지(SSS, SAS, ASA)는 반드시 암기",
      "이등변삼각형의 꼭지각의 이등분선은 밑변을 수직이등분",
    ],
    prerequisiteId: "mid1-geometry-1",
  },
  {
    id: "mid2-statistics-1",
    grade: "mid2",
    category: "statistics",
    title: "확률",
    definitions: [
      "경우의 수: 어떤 사건이 일어나는 모든 가짓수",
      "확률: 사건이 일어날 가능성을 수로 나타낸 것",
      "0 ≤ P(A) ≤ 1",
    ],
    formulas: [
      { label: "확률", latex: "P(A) = \\frac{\\text{사건 A가 일어나는 경우의 수}}{\\text{모든 경우의 수}}" },
      { label: "여사건의 확률", latex: "P(A^c) = 1 - P(A)" },
    ],
    tips: [
      "'적어도 하나'는 여사건으로 풀면 편리",
      "경우의 수: 동시에 → 곱, 또는 → 합",
    ],
    prerequisiteId: "mid1-statistics-1",
  },

  // 중3
  {
    id: "mid3-numbers-1",
    grade: "mid3",
    category: "numbers",
    title: "제곱근과 실수",
    definitions: [
      "제곱근: a의 제곱근은 x² = a를 만족하는 x",
      "무리수: 순환하지 않는 무한소수",
      "실수 = 유리수 + 무리수",
    ],
    formulas: [
      { label: "제곱근의 성질", latex: "\\sqrt{a^2} = |a|, \\quad (\\sqrt{a})^2 = a \\quad (a \\geq 0)" },
      { label: "근호 계산", latex: "\\sqrt{a} \\times \\sqrt{b} = \\sqrt{ab}, \\quad \\frac{\\sqrt{a}}{\\sqrt{b}} = \\sqrt{\\frac{a}{b}}" },
    ],
    tips: [
      "√a는 a ≥ 0일 때만 정의됨 (실수 범위)",
      "분모의 유리화: 분자, 분모에 같은 무리수를 곱하기",
    ],
    prerequisiteId: "mid2-numbers-1",
  },
  {
    id: "mid3-algebra-1",
    grade: "mid3",
    category: "algebra",
    title: "다항식의 곱셈과 인수분해",
    definitions: [
      "인수분해: 하나의 다항식을 두 개 이상의 인수의 곱으로 나타내는 것",
      "인수: 다항식을 곱의 꼴로 나타냈을 때 각각의 식",
    ],
    formulas: [
      { label: "곱셈 공식", latex: "(a+b)^2 = a^2 + 2ab + b^2" },
      { label: "곱셈 공식 2", latex: "(a-b)^2 = a^2 - 2ab + b^2" },
      { label: "합차 공식", latex: "(a+b)(a-b) = a^2 - b^2" },
      { label: "인수분해", latex: "x^2 + (a+b)x + ab = (x+a)(x+b)" },
    ],
    tips: [
      "곱셈 공식 ↔ 인수분해는 역과정!",
      "내신에서 치환을 이용한 인수분해 자주 출제",
      "완전제곱식 판별: 가운데 항 = 2×(앞)×(뒤)",
    ],
    prerequisiteId: "mid2-algebra-1",
  },
  {
    id: "mid3-functions-1",
    grade: "mid3",
    category: "functions",
    title: "이차함수",
    definitions: [
      "이차함수: y = ax² + bx + c (a ≠ 0) 꼴의 함수",
      "꼭짓점: 포물선의 최고점 또는 최저점",
      "축: 포물선의 대칭축",
    ],
    formulas: [
      { label: "표준형", latex: "y = a(x-p)^2 + q \\quad \\text{꼭짓점: } (p, q)" },
      { label: "일반형", latex: "y = ax^2 + bx + c" },
      { label: "축의 방정식", latex: "x = -\\frac{b}{2a}" },
    ],
    tips: [
      "a > 0이면 아래로 볼록, a < 0이면 위로 볼록",
      "꼭짓점 좌표 구하기: 표준형으로 변환 (완전제곱식)",
      "이차함수의 그래프 그리기는 내신 서술형 단골!",
    ],
    prerequisiteId: "mid2-functions-1",
  },
  {
    id: "mid3-geometry-1",
    grade: "mid3",
    category: "geometry",
    title: "피타고라스 정리와 삼각비",
    definitions: [
      "피타고라스 정리: 직각삼각형에서 빗변² = 밑변² + 높이²",
      "삼각비: sin, cos, tan",
      "닮음: 모양은 같고 크기가 다른 도형",
    ],
    formulas: [
      { label: "피타고라스 정리", latex: "c^2 = a^2 + b^2" },
      { label: "삼각비", latex: "\\sin\\theta = \\frac{\\text{대변}}{\\text{빗변}}, \\quad \\cos\\theta = \\frac{\\text{인접변}}{\\text{빗변}}, \\quad \\tan\\theta = \\frac{\\text{대변}}{\\text{인접변}}" },
    ],
    tips: [
      "특수각 30°, 45°, 60°의 삼각비는 반드시 암기",
      "피타고라스 정리의 역도 알아두기 (직각삼각형 판별)",
    ],
    prerequisiteId: "mid2-geometry-1",
  },
  {
    id: "mid3-statistics-1",
    grade: "mid3",
    category: "statistics",
    title: "대푯값과 산포도",
    definitions: [
      "평균: 자료의 총합 / 자료의 수",
      "중앙값: 자료를 크기순으로 나열했을 때 가운데 값",
      "분산: 편차의 제곱의 평균",
    ],
    formulas: [
      { label: "평균", latex: "\\bar{x} = \\frac{x_1 + x_2 + \\cdots + x_n}{n}" },
      { label: "분산", latex: "\\sigma^2 = \\frac{1}{n}\\sum_{i=1}^{n}(x_i - \\bar{x})^2" },
      { label: "표준편차", latex: "\\sigma = \\sqrt{\\frac{1}{n}\\sum_{i=1}^{n}(x_i - \\bar{x})^2}" },
    ],
    tips: [
      "분산 = (제곱의 평균) - (평균의 제곱)으로 계산하면 빠름",
      "표준편차가 작을수록 자료가 평균 주위에 밀집",
    ],
    prerequisiteId: "mid2-statistics-1",
  },

  // 고등 공통
  {
    id: "common-algebra-1",
    grade: "common",
    category: "algebra",
    title: "다항식의 연산과 나머지정리",
    definitions: [
      "다항식의 나눗셈: 나뉘는 식 = 나누는 식 × 몫 + 나머지",
      "나머지 정리: f(x)를 (x-a)로 나눈 나머지는 f(a)",
      "인수정리: f(a) = 0이면 f(x)는 (x-a)를 인수로 가진다",
    ],
    formulas: [
      { label: "나머지 정리", latex: "f(x) \\div (x-a) \\text{의 나머지} = f(a)" },
      { label: "인수정리", latex: "f(a) = 0 \\Leftrightarrow f(x) = (x-a)Q(x)" },
      { label: "곱셈 공식 확장", latex: "a^3 + b^3 = (a+b)(a^2 - ab + b^2)" },
    ],
    tips: [
      "조립제법으로 빠르게 나눗셈하기",
      "고차 방정식은 인수정리로 인수를 찾은 후 조립제법",
    ],
    prerequisiteId: "mid3-algebra-1",
  },
  {
    id: "common-algebra-2",
    grade: "common",
    category: "algebra",
    title: "이차방정식과 이차부등식",
    definitions: [
      "이차방정식: ax² + bx + c = 0 (a ≠ 0)",
      "판별식 D = b² - 4ac",
      "이차부등식: 이차식의 부등호 관계",
    ],
    formulas: [
      { label: "근의 공식", latex: "x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}" },
      { label: "판별식", latex: "D = b^2 - 4ac" },
      { label: "근과 계수의 관계", latex: "\\alpha + \\beta = -\\frac{b}{a}, \\quad \\alpha\\beta = \\frac{c}{a}" },
    ],
    tips: [
      "D > 0: 서로 다른 두 실근, D = 0: 중근, D < 0: 허근",
      "이차부등식은 그래프와 함께 풀면 직관적",
    ],
    prerequisiteId: "mid3-algebra-1",
  },
  {
    id: "common-functions-1",
    grade: "common",
    category: "functions",
    title: "함수와 그래프",
    definitions: [
      "합성함수: (f∘g)(x) = f(g(x))",
      "역함수: y = f(x) ↔ x = f⁻¹(y)",
      "유리함수, 무리함수의 그래프",
    ],
    formulas: [
      { label: "합성함수", latex: "(f \\circ g)(x) = f(g(x))" },
      { label: "역함수 조건", latex: "f(f^{-1}(x)) = x, \\quad f^{-1}(f(x)) = x" },
    ],
    tips: [
      "역함수 그래프는 y = x에 대칭",
      "합성함수 문제는 안쪽부터 계산!",
    ],
    prerequisiteId: "mid3-functions-1",
  },
  {
    id: "common-geometry-1",
    grade: "common",
    category: "geometry",
    title: "도형의 방정식",
    definitions: [
      "두 점 사이의 거리",
      "직선의 방정식: y = mx + n 또는 ax + by + c = 0",
      "원의 방정식: (x-a)² + (y-b)² = r²",
    ],
    formulas: [
      { label: "두 점 사이 거리", latex: "d = \\sqrt{(x_2-x_1)^2 + (y_2-y_1)^2}" },
      { label: "원의 방정식", latex: "(x-a)^2 + (y-b)^2 = r^2" },
      { label: "점과 직선 사이 거리", latex: "d = \\frac{|ax_1 + by_1 + c|}{\\sqrt{a^2 + b^2}}" },
    ],
    tips: [
      "원과 직선의 위치관계: 중심~직선 거리와 반지름 비교",
      "내분점, 외분점 공식 정확히 알아두기",
    ],
    prerequisiteId: "mid3-geometry-1",
  },
  {
    id: "common-statistics-1",
    grade: "common",
    category: "statistics",
    title: "경우의 수와 순열·조합",
    definitions: [
      "순열: n개에서 r개를 순서대로 뽑는 경우의 수",
      "조합: n개에서 r개를 순서 없이 뽑는 경우의 수",
    ],
    formulas: [
      { label: "순열", latex: "_nP_r = \\frac{n!}{(n-r)!}" },
      { label: "조합", latex: "_nC_r = \\frac{n!}{r!(n-r)!}" },
      { label: "팩토리얼", latex: "n! = n \\times (n-1) \\times \\cdots \\times 2 \\times 1" },
    ],
    tips: [
      "순서가 중요하면 순열, 순서가 상관없으면 조합",
      "중복순열: n^r, 중복조합: ₙHᵣ = ₙ₊ᵣ₋₁Cᵣ",
    ],
    prerequisiteId: "mid3-statistics-1",
  },

  // 수I/II
  {
    id: "math12-algebra-1",
    grade: "math12",
    category: "algebra",
    title: "지수와 로그",
    definitions: [
      "지수의 확장: 유리수, 실수 지수",
      "로그: aˣ = N ⟺ x = logₐN",
      "상용로그: 밑이 10인 로그",
    ],
    formulas: [
      { label: "로그의 정의", latex: "a^x = N \\Leftrightarrow x = \\log_a N \\quad (a > 0, a \\neq 1, N > 0)" },
      { label: "로그 성질", latex: "\\log_a MN = \\log_a M + \\log_a N" },
      { label: "밑 변환 공식", latex: "\\log_a b = \\frac{\\log_c b}{\\log_c a}" },
    ],
    tips: [
      "로그 진수 조건(>0)과 밑 조건(>0, ≠1) 반드시 확인",
      "상용로그의 정수부분, 소수부분 개념 정리하기",
    ],
    prerequisiteId: "common-algebra-1",
  },
  {
    id: "math12-functions-1",
    grade: "math12",
    category: "functions",
    title: "삼각함수",
    definitions: [
      "호도법: 180° = π 라디안",
      "삼각함수: sin, cos, tan의 확장",
      "삼각함수의 그래프: 주기함수",
    ],
    formulas: [
      { label: "호도법", latex: "180° = \\pi \\text{ rad}" },
      { label: "삼각함수 기본 관계", latex: "\\sin^2\\theta + \\cos^2\\theta = 1" },
      { label: "덧셈정리", latex: "\\sin(\\alpha \\pm \\beta) = \\sin\\alpha\\cos\\beta \\pm \\cos\\alpha\\sin\\beta" },
    ],
    tips: [
      "단위원 위의 점 (cosθ, sinθ)을 시각화하면 이해가 쉬움",
      "주기: sin, cos → 2π, tan → π",
    ],
    prerequisiteId: "common-functions-1",
  },
  {
    id: "math12-functions-2",
    grade: "math12",
    category: "functions",
    title: "수열",
    definitions: [
      "등차수열: 연속된 두 항의 차가 일정",
      "등비수열: 연속된 두 항의 비가 일정",
      "수열의 합: 시그마(Σ) 기호 사용",
    ],
    formulas: [
      { label: "등차수열 일반항", latex: "a_n = a_1 + (n-1)d" },
      { label: "등차수열의 합", latex: "S_n = \\frac{n(a_1 + a_n)}{2}" },
      { label: "등비수열 일반항", latex: "a_n = a_1 \\cdot r^{n-1}" },
      { label: "등비수열의 합", latex: "S_n = \\frac{a_1(r^n - 1)}{r - 1} \\quad (r \\neq 1)" },
    ],
    tips: [
      "수열의 합 Sₙ과 일반항 aₙ의 관계: aₙ = Sₙ - Sₙ₋₁ (n≥2)",
      "수학적 귀납법: 증명의 기본 단계 2가지를 정확히!",
    ],
    prerequisiteId: "common-algebra-2",
  },
  {
    id: "math12-geometry-1",
    grade: "math12",
    category: "geometry",
    title: "벡터",
    definitions: [
      "벡터: 크기와 방향을 가진 양",
      "위치벡터: 시점이 원점인 벡터",
      "내적: 두 벡터의 곱",
    ],
    formulas: [
      { label: "벡터의 크기", latex: "|\\vec{a}| = \\sqrt{a_1^2 + a_2^2}" },
      { label: "내적", latex: "\\vec{a} \\cdot \\vec{b} = |\\vec{a}||\\vec{b}|\\cos\\theta" },
      { label: "성분 내적", latex: "\\vec{a} \\cdot \\vec{b} = a_1b_1 + a_2b_2" },
    ],
    tips: [
      "두 벡터가 수직 ⟺ 내적 = 0",
      "벡터의 평행 조건: 한 쪽이 다른 쪽의 실수배",
    ],
    prerequisiteId: "common-geometry-1",
  },
  {
    id: "math12-statistics-1",
    grade: "math12",
    category: "statistics",
    title: "확률분포와 통계적 추정",
    definitions: [
      "확률변수: 표본공간의 각 원소에 실수를 대응시키는 함수",
      "이항분포: B(n, p)",
      "정규분포: N(μ, σ²)",
    ],
    formulas: [
      { label: "이항분포의 평균과 분산", latex: "E(X) = np, \\quad V(X) = np(1-p)" },
      { label: "정규분포 표준화", latex: "Z = \\frac{X - \\mu}{\\sigma}" },
      { label: "모평균 신뢰구간", latex: "\\bar{x} - z_{\\alpha/2}\\frac{\\sigma}{\\sqrt{n}} \\leq \\mu \\leq \\bar{x} + z_{\\alpha/2}\\frac{\\sigma}{\\sqrt{n}}" },
    ],
    tips: [
      "이항분포에서 n이 크면 정규분포로 근사 가능",
      "표본평균의 분포: 표준편차가 σ/√n으로 줄어듦",
    ],
    prerequisiteId: "common-statistics-1",
  },

  // 미적분
  {
    id: "calculus-functions-1",
    grade: "calculus",
    category: "functions",
    title: "함수의 극한과 연속",
    definitions: [
      "함수의 극한: x가 a에 한없이 가까워질 때 f(x)가 다가가는 값",
      "연속: lim f(x) = f(a)일 때 x=a에서 연속",
      "중간값 정리: 연속함수는 중간값을 반드시 가진다",
    ],
    formulas: [
      { label: "극한의 성질", latex: "\\lim_{x \\to a}[f(x) + g(x)] = \\lim_{x \\to a}f(x) + \\lim_{x \\to a}g(x)" },
      { label: "중요 극한", latex: "\\lim_{x \\to 0}\\frac{\\sin x}{x} = 1" },
    ],
    tips: [
      "좌극한 ≠ 우극한이면 극한값이 존재하지 않음",
      "부정형(0/0, ∞/∞)은 인수분해나 유리화로 해결",
    ],
    prerequisiteId: "math12-functions-1",
  },
  {
    id: "calculus-functions-2",
    grade: "calculus",
    category: "functions",
    title: "미분법",
    definitions: [
      "미분계수: 함수의 순간변화율",
      "도함수: f'(x) = lim[h→0] {f(x+h) - f(x)} / h",
      "접선의 기울기 = 미분계수",
    ],
    formulas: [
      { label: "미분의 정의", latex: "f'(x) = \\lim_{h \\to 0}\\frac{f(x+h) - f(x)}{h}" },
      { label: "거듭제곱 미분", latex: "\\frac{d}{dx}x^n = nx^{n-1}" },
      { label: "곱의 미분", latex: "(fg)' = f'g + fg'" },
      { label: "합성함수 미분 (연쇄법칙)", latex: "\\frac{dy}{dx} = \\frac{dy}{du} \\cdot \\frac{du}{dx}" },
      { label: "삼각함수 미분", latex: "(\\sin x)' = \\cos x, \\quad (\\cos x)' = -\\sin x" },
      { label: "지수·로그 미분", latex: "(e^x)' = e^x, \\quad (\\ln x)' = \\frac{1}{x}" },
    ],
    tips: [
      "극대·극소 판별: f'(x) = 0인 점에서 부호 변화 확인",
      "접선의 방정식: y - f(a) = f'(a)(x - a)",
      "미분 가능하면 연속이지만, 연속이라고 미분 가능한 건 아님",
    ],
    prerequisiteId: "calculus-functions-1",
  },
  {
    id: "calculus-functions-3",
    grade: "calculus",
    category: "functions",
    title: "적분법",
    definitions: [
      "부정적분: 미분의 역과정",
      "정적분: 구간 [a,b]에서의 넓이",
      "미적분의 기본정리: 미분과 적분은 역연산",
    ],
    formulas: [
      { label: "부정적분", latex: "\\int x^n dx = \\frac{x^{n+1}}{n+1} + C \\quad (n \\neq -1)" },
      { label: "정적분", latex: "\\int_a^b f(x)dx = F(b) - F(a)" },
      { label: "치환적분", latex: "\\int f(g(x))g'(x)dx = \\int f(u)du" },
      { label: "부분적분", latex: "\\int f(x)g'(x)dx = f(x)g(x) - \\int f'(x)g(x)dx" },
      { label: "넓이", latex: "S = \\int_a^b |f(x) - g(x)|dx" },
    ],
    tips: [
      "적분상수 C 빼먹지 않기! (부정적분)",
      "넓이 구할 때 위쪽 함수 - 아래쪽 함수",
      "속도의 적분 = 거리, 가속도의 적분 = 속도",
    ],
    prerequisiteId: "calculus-functions-2",
  },
  {
    id: "calculus-algebra-1",
    grade: "calculus",
    category: "algebra",
    title: "급수",
    definitions: [
      "급수: 수열의 항을 차례로 더한 것",
      "무한급수: 무한히 많은 항의 합",
      "수렴: 부분합의 극한이 존재",
    ],
    formulas: [
      { label: "등비급수", latex: "\\sum_{n=1}^{\\infty} ar^{n-1} = \\frac{a}{1-r} \\quad (|r| < 1)" },
      { label: "급수의 수렴 조건", latex: "\\sum a_n \\text{ 수렴} \\Rightarrow \\lim_{n \\to \\infty} a_n = 0" },
    ],
    tips: [
      "|r| ≥ 1이면 등비급수는 발산",
      "부분합 Sₙ을 구해서 n→∞ 극한으로 수렴/발산 판별",
    ],
    prerequisiteId: "math12-functions-2",
  },
];

// Get topics for a specific grade
export function getTopicsByGrade(gradeId: string): MathTopic[] {
  return TOPICS.filter((t) => t.grade === gradeId);
}

// Get topics for a specific category across all grades (for roadmap)
export function getTopicsByCategory(categoryId: string): MathTopic[] {
  return TOPICS.filter((t) => t.category === categoryId);
}

// Get a single topic by ID
export function getTopicById(id: string): MathTopic | undefined {
  return TOPICS.find((t) => t.id === id);
}
