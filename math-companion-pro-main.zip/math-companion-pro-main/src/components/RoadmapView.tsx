import { CATEGORIES, GRADES, getTopicsByCategory } from "@/data/mathCurriculum";

interface RoadmapViewProps {
  onTopicClick: (topicId: string) => void;
}

const categoryColors: Record<string, { bg: string; border: string; dot: string }> = {
  numbers: { bg: "bg-primary/10", border: "border-primary/30", dot: "bg-primary" },
  algebra: { bg: "bg-accent/10", border: "border-accent/30", dot: "bg-accent" },
  functions: { bg: "bg-success/10", border: "border-success/30", dot: "bg-success" },
  geometry: { bg: "bg-warning/10", border: "border-warning/30", dot: "bg-warning" },
  statistics: { bg: "bg-destructive/10", border: "border-destructive/30", dot: "bg-destructive" },
};

const RoadmapView = ({ onTopicClick }: RoadmapViewProps) => {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-bold text-foreground">계통별 로드맵</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          같은 영역이 중학교부터 고등 미적분까지 어떻게 연결되는지 한눈에 확인하세요
        </p>
      </div>

      {CATEGORIES.map((cat) => {
        const topics = getTopicsByCategory(cat.id);
        const colors = categoryColors[cat.id];
        if (topics.length === 0) return null;

        return (
          <div key={cat.id} className="rounded-xl border border-border bg-card p-5">
            <h3 className="mb-4 text-base font-semibold text-card-foreground">{cat.label}</h3>
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-3 top-0 bottom-0 w-0.5 bg-border" />
              <div className="space-y-3">
                {GRADES.map((grade) => {
                  const gradeTopics = topics.filter((t) => t.grade === grade.id);
                  if (gradeTopics.length === 0) return null;
                  return gradeTopics.map((topic) => (
                    <button
                      key={topic.id}
                      onClick={() => onTopicClick(topic.id)}
                      className={`relative ml-8 w-[calc(100%-2rem)] rounded-lg border ${colors.border} ${colors.bg} px-4 py-3 text-left transition-all hover:shadow-sm hover:-translate-y-0.5`}
                    >
                      {/* Dot on timeline */}
                      <div className={`absolute -left-[1.625rem] top-4 h-2.5 w-2.5 rounded-full ${colors.dot} ring-2 ring-card`} />
                      <span className="text-[11px] font-medium text-muted-foreground">{grade.label}</span>
                      <p className="text-sm font-semibold text-card-foreground">{topic.title}</p>
                    </button>
                  ));
                })}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default RoadmapView;
