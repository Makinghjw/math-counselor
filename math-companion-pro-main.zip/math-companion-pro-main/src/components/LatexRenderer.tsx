import "katex/dist/katex.min.css";
import katex from "katex";
import { useMemo } from "react";

interface LatexRendererProps {
  latex: string;
  displayMode?: boolean;
  className?: string;
}

const LatexRenderer = ({ latex, displayMode = false, className = "" }: LatexRendererProps) => {
  const html = useMemo(() => {
    try {
      return katex.renderToString(latex, {
        displayMode,
        throwOnError: false,
        trust: true,
      });
    } catch {
      return latex;
    }
  }, [latex, displayMode]);

  return (
    <span
      className={className}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};

export default LatexRenderer;
