import { useStudyTimer } from "@/hooks/useStudyTimer";
import { Play, Pause, Square, Clock } from "lucide-react";

const StudyTimer = () => {
  const { isRunning, elapsed, start, pause, stop, formatTime, todayTotal, logs } = useStudyTimer();

  const recentLogs = logs.slice(-7).reverse();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-foreground">⏱️ 내신 타이머</h2>
        <p className="mt-1 text-sm text-muted-foreground">공부 시간을 기록하고 관리하세요</p>
      </div>

      {/* Timer display */}
      <div className="rounded-2xl border border-border bg-card p-8 text-center">
        <p className="text-5xl font-mono font-bold tracking-wider text-card-foreground">
          {formatTime(elapsed)}
        </p>
        <div className="mt-6 flex justify-center gap-3">
          {!isRunning ? (
            <button
              onClick={start}
              className="flex items-center gap-2 rounded-xl gradient-primary px-6 py-3 text-sm font-medium text-primary-foreground shadow-md transition-transform hover:scale-105"
            >
              <Play className="h-4 w-4" />
              시작
            </button>
          ) : (
            <button
              onClick={pause}
              className="flex items-center gap-2 rounded-xl bg-secondary px-6 py-3 text-sm font-medium text-secondary-foreground transition-colors hover:bg-secondary/80"
            >
              <Pause className="h-4 w-4" />
              일시정지
            </button>
          )}
          <button
            onClick={stop}
            disabled={elapsed === 0}
            className="flex items-center gap-2 rounded-xl border border-border px-6 py-3 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted disabled:opacity-40"
          >
            <Square className="h-4 w-4" />
            저장 & 종료
          </button>
        </div>
      </div>

      {/* Today summary */}
      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center gap-2 text-sm font-semibold text-card-foreground">
          <Clock className="h-4 w-4 text-primary" />
          오늘 총 공부 시간
        </div>
        <p className="mt-2 text-3xl font-mono font-bold gradient-text">
          {formatTime(todayTotal + (isRunning ? elapsed : 0))}
        </p>
      </div>

      {/* Recent logs */}
      {recentLogs.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="text-sm font-semibold text-card-foreground mb-3">최근 기록</h3>
          <div className="space-y-2">
            {recentLogs.map((log) => (
              <div key={log.date} className="flex justify-between items-center rounded-lg bg-muted/50 px-4 py-2.5">
                <span className="text-sm text-muted-foreground">{log.date}</span>
                <span className="text-sm font-mono font-medium text-card-foreground">{formatTime(log.seconds)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default StudyTimer;
