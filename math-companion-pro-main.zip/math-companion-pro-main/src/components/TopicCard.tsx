import { MathTopic, CATEGORIES } from "@/data/mathCurriculum";
import { BookOpen } from "lucide-react";

interface TopicCardProps {
  topic: MathTopic;
  onClick: () => void;
}

const categoryColorMap: Record<string, string> = {
  numbers: "border-l-primary bg-primary/5",
  algebra: "border-l-accent bg-accent/5",
  functions: "border-l-success bg-success/5",
  geometry: "border-l-warning bg-warning/5",
  statistics: "border-l-destructive bg-destructive/5",
};

const TopicCard = ({ topic, onClick }: TopicCardProps) => {
  const cat = CATEGORIES.find((c) => c.id === topic.category);
  const colorClass = categoryColorMap[topic.category] ?? "border-l-primary bg-primary/5";

  return (
    <button
      onClick={onClick}
      className={`group w-full rounded-xl border border-border/50 border-l-4 ${colorClass} p-5 text-left transition-all duration-200 hover:shadow-md hover:-translate-y-0.5`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1">
          <span className="mb-1.5 inline-block rounded-md bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
            {cat?.label}
          </span>
          <h3 className="text-base font-semibold text-card-foreground group-hover:text-primary transition-colors">
            {topic.title}
          </h3>
          <p className="mt-1.5 text-sm text-muted-foreground line-clamp-2">
            {topic.definitions[0]}
          </p>
        </div>
        <BookOpen className="h-5 w-5 shrink-0 text-muted-foreground/50 group-hover:text-primary transition-colors" />
      </div>
      <div className="mt-3 flex gap-2 text-xs text-muted-foreground">
        <span>공식 {topic.formulas.length}개</span>
        <span>·</span>
        <span>꿀팁 {topic.tips.length}개</span>
      </div>
    </button>
  );
};

export default TopicCard;
