import { GRADES } from "@/data/mathCurriculum";

interface GradeTabsProps {
  activeGrade: string;
  onGradeChange: (grade: string) => void;
}

const GradeTabs = ({ activeGrade, onGradeChange }: GradeTabsProps) => {
  return (
    <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
      {GRADES.map((grade) => (
        <button
          key={grade.id}
          onClick={() => onGradeChange(grade.id)}
          className={`whitespace-nowrap rounded-lg px-4 py-2.5 text-sm font-medium transition-all duration-200 ${
            activeGrade === grade.id
              ? "gradient-primary text-primary-foreground shadow-md"
              : "bg-card text-muted-foreground hover:bg-secondary hover:text-secondary-foreground border border-border"
          }`}
        >
          {grade.label}
        </button>
      ))}
    </div>
  );
};

export default GradeTabs;
