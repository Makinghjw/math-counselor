import { useState, useCallback } from "react";
import { getTopicsByGrade, getTopicById, GRADES } from "@/data/mathCurriculum";
import { useBookmarks } from "@/hooks/useBookmarks";
import GradeTabs from "@/components/GradeTabs";
import TopicCard from "@/components/TopicCard";
import TopicDetail from "@/components/TopicDetail";
import RoadmapView from "@/components/RoadmapView";
import FormulaBook from "@/components/FormulaBook";
import StudyTimer from "@/components/StudyTimer";
import { BookOpen, Map, Bookmark, Timer, GraduationCap } from "lucide-react";

type View = "grades" | "roadmap" | "formulas" | "timer";

const Index = () => {
  const [view, setView] = useState<View>("grades");
  const [activeGrade, setActiveGrade] = useState("mid1");
  const [selectedTopicId, setSelectedTopicId] = useState<string | null>(null);
  const { bookmarks, toggleBookmark, isBookmarked } = useBookmarks();

  const topics = getTopicsByGrade(activeGrade);
  const selectedTopic = selectedTopicId ? getTopicById(selectedTopicId) : null;

  const handleTopicClick = useCallback((topicId: string) => {
    const topic = getTopicById(topicId);
    if (topic) {
      setSelectedTopicId(topicId);
      setActiveGrade(topic.grade);
      setView("grades");
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, []);

  const navItems = [
    { id: "grades" as const, label: "학년별", icon: BookOpen },
    { id: "roadmap" as const, label: "계통도", icon: Map },
    { id: "formulas" as const, label: "보관함", icon: Bookmark, badge: bookmarks.length || undefined },
    { id: "timer" as const, label: "타이머", icon: Timer },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-border bg-card/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-primary">
              <GraduationCap className="h-4.5 w-4.5 text-primary-foreground" />
            </div>
            <h1 className="text-lg font-bold text-foreground">수학 학습 도우미</h1>
          </div>
        </div>

        {/* Navigation */}
        <div className="mx-auto max-w-3xl px-4 pb-2">
          <nav className="flex gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setView(item.id);
                  setSelectedTopicId(null);
                }}
                className={`relative flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  view === item.id
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                }`}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
                {item.badge && (
                  <span className="ml-0.5 flex h-4 min-w-[1rem] items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Content */}
      <main className="mx-auto max-w-3xl px-4 py-6">
        {view === "grades" && !selectedTopic && (
          <div className="space-y-5">
            <GradeTabs activeGrade={activeGrade} onGradeChange={(g) => { setActiveGrade(g); setSelectedTopicId(null); }} />
            <div className="grid gap-3 sm:grid-cols-2">
              {topics.map((topic) => (
                <TopicCard
                  key={topic.id}
                  topic={topic}
                  onClick={() => setSelectedTopicId(topic.id)}
                />
              ))}
            </div>
          </div>
        )}

        {view === "grades" && selectedTopic && (
          <TopicDetail
            topic={selectedTopic}
            onBack={() => setSelectedTopicId(null)}
            onNavigate={handleTopicClick}
            isBookmarked={isBookmarked}
            onToggleBookmark={toggleBookmark}
          />
        )}

        {view === "roadmap" && (
          <RoadmapView onTopicClick={handleTopicClick} />
        )}

        {view === "formulas" && (
          <FormulaBook bookmarks={bookmarks} onRemove={toggleBookmark} />
        )}

        {view === "timer" && <StudyTimer />}
      </main>
    </div>
  );
};

export default Index;
